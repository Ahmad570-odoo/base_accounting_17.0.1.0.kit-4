## Module <base_account_budget>

#### 07.11.2023
#### Version 17.0.1.0.0
#### ADD
- Initial commit for Budget Management

#### 02.01.2024
#### Version 17.0.1.0.1
#### FIX
- Bug Fixed, states and tracking_visibility parameter removed from the fields of budget.budget model.